// makeGrid Function creates the grid consisting of table rows and columns
function makeGrid(rows, columns) {
	// Clear the grid
	$( 'tbody' ).remove();
	// Create and label the grid rows
	for (var rowCounter = 1; rowCounter <= rows; rowCounter++) {
		$( 'table' ).append('<tr></tr>');
		// Create and label the grid columns
		for (var columnCounter = 1; columnCounter <= columns; columnCounter++) {
			$('tr:last').append('<td></td>');
		}
    }
	// Set the color of the clicked cell
	$('td').click (function setColor() {
		const color = $('#colorPicker').val();
		if ($(this).attr ('style')) {
			$(this).removeAttr('style')
		} else {
			$(this).attr('style' , 'background-color:' + color);
		}
	})
}
// Set grid size
$( '#sizePicker' ).submit(function(event) {
	event.preventDefault();
	const gridRows = $('#inputHeight').val();
	const gridColumns = $('#inputWidth').val();
	// When size is submitted by the user, call makeGrid()
	makeGrid(gridRows, gridColumns);
});
